I have put the additions I needed to make to the 5.3.1 
distribution of pgplot that I got from Tim Pearson in July 2011.
They are mainly the gfortran_gcc.conf files for Linux and OSX, but 
I have also put the basic drivers.list file that I use for
SCHED here.

Craig Walker
